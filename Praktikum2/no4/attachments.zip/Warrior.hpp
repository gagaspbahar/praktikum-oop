#ifndef __WARRIOR_HPP__
#define __WARRIOR_HPP__

class Warrior {
public:
  virtual void powerUp() = 0;
};

#endif